Imports Cryptware.NSLE4442API
Imports Cryptware.NSCAPI
Imports System.Text


Imports System.Runtime.InteropServices

Module Module1

	Sub Main()

		Dim nRes As Long
		Dim memory() As Byte
		Dim defaultPin(2) As Byte
		Dim pin(2) As Byte
		Dim newpin(2) As Byte

		On Error GoTo hError

		Dim scman As SmartCardManager = New SmartCardManager()
		Dim readers As Readers = scman.PluggedReaders
		Dim reader As Reader = readers(0)

		' wait for smart card inserted
		reader.WaitForSmartCardInserted()

		'creates a new SLE4442 instance
		Dim sle As SLE4442 = New SLE4442()

		nRes = sle.Connect(reader)
		If (nRes <> 0) Then
			Console.WriteLine("Connect error: " + nRes)
			Exit Sub
		End If

		defaultPin(0) = &HFF
		defaultPin(1) = &HFF
		defaultPin(2) = &HFF

		newpin(0) = &H33 '1
		newpin(1) = &H32 '2
		newpin(2) = &H31 '3

		' newpin is 123

		' verifies the PIN
		nRes = sle.VerifyPIN(defaultPin)
		If (nRes <> 0) Then
			Console.WriteLine("invalid PIN")
			nRes = sle.VerifyPIN(newpin)
			If (nRes <> 0) Then
				Console.WriteLine("invalid PIN")
			End If
		Else
			nRes = sle.ChangePIN(defaultPin, newpin)
			If (nRes <> 0) Then
				Console.WriteLine("invalid ChangePIN")
			End If
		End If


		' reads 10 bytes from the main memory
		memory = sle.ReadMainMemory(32, 10)

		memory = Encoding.ASCII.GetBytes("test test test")

		' updates  the main memory
        sle.UpdateMainMemory(memory, 0, 32)

		' reads 10 bytes from the main memory
		memory = sle.ReadMainMemory(32, 10)

		nRes = sle.ChangePIN(newpin, defaultPin)
		If (nRes <> 0) Then
			Console.WriteLine("invalid ChangePIN")
		End If

		Exit Sub
hError:

        Dim ex As Exception = Err.GetException()

        Console.WriteLine("exception " + ex.Message)

            
    End Sub

End Module
