using System;
using System.Collections.Generic;
using System.Text;
using Cryptware.NSCAPI;
using Cryptware.NSLE4442API;

namespace TestNSLE4442API
{
    class Program
    {
        static void Main(string[] args)
        {
            try
            {
                // create a smart card manager
                SmartCardManager scman = new SmartCardManager();

                Reader reader = scman.PluggedReaders[0];

                reader.WaitForSmartCardInserted();

                //creates a new SLE4442 instance
                SLE4442 sle = new SLE4442();

                int nRes = sle.Connect(reader);
                if (nRes != 0)
                {
                    Console.WriteLine("Connect error: " + nRes);
                    return;
                }

                // verifies the PIN
                nRes = sle.VerifyPIN(new byte[] { 0xff, 0xff, 0xff });
                if (nRes != 0)
                {
                    Console.WriteLine("invalid PIN");
                }
                else
                {
                    // reads 10 bytes from the main memory
                    byte[] memory = sle.ReadMainMemory(0, 10);

                    nRes = sle.ChangePIN(new byte[] { 0xff, 0xff, 0xff }, new byte[] { 0x31, 0x32, 0x33 });
                    if (nRes != 0)
                    {
                        Console.WriteLine("invalid ChangePIN");
                    }

                    nRes = sle.VerifyPIN(new byte[] { 0x31, 0x32, 0x33 });
                    if (nRes != 0)
                    {
                        Console.WriteLine("invalid PIN");
                    }

                    nRes = sle.ChangePIN(new byte[] { 0x31, 0x32, 0x33 }, new byte[] { 0xff, 0xff, 0xff });
                    if (nRes != 0)
                    {
                        Console.WriteLine("invalid PIN");
                    }

                    nRes = sle.VerifyPIN(new byte[] { 0xff, 0xff, 0xff });
                    if (nRes != 0)
                    {
                        Console.WriteLine("invalid PIN");
                    }
                }
            }
            catch (SmartCardException ex)
            {
                Console.WriteLine("exception " + ex.Message);
            }
        }
    }
}
