import java.math.BigInteger;
import java.util.List;

import com.cryptware.jscapi.PCSCException;
import com.cryptware.jscapi.Reader;
import com.cryptware.jscapi.SmartCardManager;
import com.cryptware.jsle4442api.SLE4442;


public class TestJSLE4442API {

	/**
	 * @param args
	 */
	public static void main(String[] args) 
	{
		try
		{
			SmartCardManager scman = new SmartCardManager();
	
	        List<Reader> readerList = scman.getPluggedReaders();
	
	        if(readerList.size() == 0)
	        {
	        	System.out.println("No readers found");
	        	return;		        	
	        }
	        
	        // Get the first reader in the list
	        Reader reader = readerList.get(0);
	
	        System.out.println(reader.getName());       
	        System.out.println(reader.isSmartCardPresent());
	
	        reader.WaitForSmartCardInserted();
	      
	        try
	        {
	        	SLE4442.loadNativeLibrary();
	        }
	        catch(RuntimeException ex)
	        {
	        	ex.printStackTrace();
	        	return;
	        }
	        
	        int ret = SLE4442.open();
	        if(ret != 0)
	        {
	        	System.out.println("Open error: " + ret);
	        	return;
	        }
	        
	        ret = SLE4442.connect(reader);
	        if(ret != 0)
	        {
	        	System.out.println("Connect error: " + ret);
	        	return;
	        }
	        
	        byte buffer[] = new byte[256];
	        
	        ret = SLE4442.readMainMemory(buffer, 0, 50);
	        if(ret != 0)
	        {
	        	System.out.println("Read main memory error: " + ret);
	        	return;
	        }
	        
	        System.out.println(new String(buffer));
	        System.out.println(new BigInteger(1, buffer).toString(16).toUpperCase());	        
	        
	        // default PIN is FFFFFF
	        byte defaultPin[] = {(byte)0xFF, (byte)0xFF, (byte)0xFF};
	        byte pin[] = {'1', '2', '3'};
	        
	        ret = SLE4442.verifyPIN(defaultPin);
	        if(ret != 0)
	        {
	        	System.out.println("Verify default PIN error: " + ret);
	        	ret = SLE4442.verifyPIN(pin);
	        	if(ret != 0)
		        {
		        	System.out.println("Verify PIN error: " + ret);
		        	return;
		        }
	        }
	        else
	        {
	        	// change default PIN
	        	
		        
	
		        ret = SLE4442.changePIN(defaultPin, pin);
		        if(ret != 0)
		        {
		        	System.out.println("changePIN error: " + ret);
		        	return;
		        }
	        }	
	        
	        buffer = ("test test test").getBytes();
	        
	        ret = SLE4442.updateMainMemory(buffer, 32, buffer.length);	        
	        if(ret != 0)
	        {
	        	System.out.println("Read main memory error: " + ret);
	        	return;
	        }
	        
	        ret = SLE4442.writeProtectionMemoryBits(buffer, 0, 1);	        
	        if(ret != 0)
	        {
	        	System.out.println("writeProtectionMemoryBits error: " + ret);
	        	return;
	        }
	        
	        SLE4442.disconnect();
	        
	        SLE4442.close();	        
		}
		catch(PCSCException ex)
		{
			ex.printStackTrace();
		}
	}

}
