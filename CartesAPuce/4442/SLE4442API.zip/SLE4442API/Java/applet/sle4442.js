/*
 * SLE4442 Javascript
 * Author: Ugo Chirico
 * Blog: http://www.ugochirico.com
 * Company: http://www.cryptware.it
 * Home: http://www.ugosweb.com
 *
 *  Copyright (C) 2010 By Ugo Chirico. All rights reserved
 * 
 *  This script is free software; you can redistribute it and/or
 *  modify it under the terms of the GNU Lesser General Public
 *  License, version 2.1 as published by the Free Software Foundation.
 *
 *  This script is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *  Lesser General Public License for more details.
 *
 *  You should have received a copy of the GNU Lesser General Public
 *  License along with this library; if not, write to the Free Software
 *  Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston,
 *  MA  02110-1301  USA
 */

var wasPresent = false;
var loaded = false;
var applet;

$(document).ready(onLoad);

function onLoad()
{
	loaded = true;
	applet = $('#sle4442Applet')[0];
				
	// in caso di refresh della pagina assicura che la lib SLE4442 sia chiusa
	applet.disconnect();
	applet.close(); 
	
	var ret = applet.open();
	if(ret != 0)
	{
		showError("Errore nell'apertura della libreria: " + ret);		
	}
	
	if(!applet.isReaderPresent())
	{
		showError("Nessun lettore di smart card individuato");
		wasPresent = false;
			
		$('#data').empty();
	}
	
	window.setTimeout("monitor()", 100);        	
}

// monitora il lettore
function monitor()
{
	if(!applet.isReaderPresent())
	{
		showError("Nessun lettore di smart card individuato");
		wasPresent = false;
			
		$('#data').empty();
		
		window.setTimeout("monitor()", 1500); 
		return;
	}

	var ret;
	if(!wasPresent)
	{
		ret = applet.connect();
		if(ret == 0)
		{			
			ret = updateData();
			if(ret != 0)
			{
				showError("Impossibile leggere dalla smart card [" + ret + "]<br>Assicurarsi che la smart card sia effetivamente una SLE4442 e che sia inserita correttamente nel lettore<br>");
				window.setTimeout("monitor()", 1500);
				return;
			}
			
			wasPresent = true;

			showError("");
			
			window.setTimeout("monitor()", 2000);  
		}
		else if(ret == applet.ERROR_REMOVED_CARD)
		{
			showError("Inserire la smart card nel lettore");
			window.setTimeout("monitor()", 1500);
		}
		else
		{
			showError("Impossibile leggere dalla smart card [" + ret + "]<br>Assicurarsi che la smart card sia effetivamente una SLE4442 e che sia inserita correttamente nel lettore<br>"+applet.getLastError());
			window.setTimeout("monitor()", 1500);
		}
	}
	else // wasPresent = true
	{
		if(!applet.isSmartCardPresent())
		{		
			wasPresent = false;
			$('#data').empty();
			
			applet.disconnect();
			
			showError("Inserire la smart card nel lettore");
			
			window.setTimeout("monitor()", 100);  
		}
		else
		{
			window.setTimeout("monitor()", 2000);  
		}
	}	
}

// legge il serial number e aggiorna il campo nella pagina
function updateData()
{		
	try
	{				
		var data = applet.readMainMemory(32, 10);
		if(data == null)
		{
			return applet.getLastError();			
		}
		
		$('#data').empty();
		$('#data').append(data);
		
		return 0;
	}
	catch(e)
	{			
		return applet.getLastError();
	}		
}

// scrive il serial number
function updateMainMemory()
{
	var pin = $('#pin').val();
	var data = $('#dataToWrite').val();
	var res = applet.verifyPIN(pin);
	if(res != 0)
		showError("Errore: " + res);
	
	res = applet.updateMainMemory(data, 32, data.length);
	if(res != 0)
	{
		showError("Errore: " + res);
	}
	else
	{
		showError("Dati modificati con successo");		
		updateData();
	}
}

// cambia il PIN di default da FFFFFF al pin dato
function changeDefaultPIN()
{
	var pin = $('#dpin').val();
	var res = applet.changeDefaultPIN(pin);
	if(res != 0)
		showError("Errore: " + res);
	else
		showError("PIN modificato con successo");
}

// cambia il PIN
function changePIN()
{	
	var newpin = $('#newpin').val();
	var oldpin = $('#oldpin').val();

	var res = applet.changePIN(oldpin, newpin);
	
	if(res != 0)
		showError("Errore: " + res);
	else
		showError("PIN modificato con successo");
}

function showError(msg)
{
	$('#error').empty();
	$('#error').append(msg);
}