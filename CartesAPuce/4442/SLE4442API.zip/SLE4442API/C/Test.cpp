// Test.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"
#include <windows.h>

#include <stdlib.h>
#include <stdio.h>
#include <string.h>

#include "..\SLE4442Lib\SLE4442Lib.h"

int _tmain(int argc, _TCHAR* argv[])
{
	// open lib
	long nRes = OpenLib();
	if(nRes != 0)
		exit(nRes);

	// get readers
	// readers are separated by ;
	char readers[256];
	int len;
	nRes = GetReaderList(readers, &len);
	if(nRes != 0)
		exit(nRes);

	//Get the first reader
	char* reader = strtok(readers, ";");

	// wait for reader inserted
	nRes = WaitForSmartCardInserted(reader, INFINITE);  // INFINTE = -1 
	if(nRes != 0)
		exit(nRes);

	// Connect to the first reader
	nRes = Connect(reader);
	if(nRes != 0)
		exit(nRes);


	BYTE memory[256];
	len = 256;
	
	// read main memory
	nRes = ReadMainMemory(memory, 0, &len);		
	if(nRes != 0)
		exit(nRes);

	memset(memory, 0, 256);

	BYTE pin[] = {0xFF,0xFF,0xFF}; // default manufacturer PIN	

	// verify PIN for writing
	nRes = VerifyPIN(pin, 3);		
	if(nRes != 0)
		exit(nRes);

	// update main memory
	nRes = UpdateMainMemory(memory, 50, 100);		
	if(nRes != 0)
		exit(nRes);

	// set new PIN
	pin[0] = '1';
	pin[1] = '2';
	pin[2] = '3';

	nRes = SetPIN(pin, 3);		
	if(nRes != 0)
		exit(nRes);


	// wait for reader inserted
	nRes = WaitForSmartCardRemoved(reader, INFINITE);  // INFINTE = -1 
	if(nRes != 0)
		exit(nRes);

	return 0;
}

