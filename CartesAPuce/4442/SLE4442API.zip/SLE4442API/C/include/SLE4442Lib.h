// The following ifdef block is the standard way of creating macros which make exporting 
// from a DLL simpler. All files within this DLL are compiled with the SLE4442LIB_EXPORTS
// symbol defined on the command line. this symbol should not be defined on any project
// that uses this DLL. This way any other project whose source files include this file see 
// SLE4442LIB_API functions as being imported from a DLL, whereas this DLL sees symbols
// defined with this macro as being exported.
#ifdef SLE4442LIB_EXPORTS
#define SLE4442LIB_API __declspec(dllexport)
#else
#define SLE4442LIB_API __declspec(dllimport)
#endif

#include <winscard.h>

/// Opens the library and creates a new context with the smart card reader
SLE4442LIB_API long _stdcall OpenLib();

/// closes the library
SLE4442LIB_API long _stdcall CloseLib();

/// Gets the list of connected readers
/// Readers are separated by ;
SLE4442LIB_API long _stdcall GetReaderList(char* szReaders, int* pnLen);

/// Connects to the given reader
SLE4442LIB_API long _stdcall Connect(char* szReader);

/// Disconnect to the given reader
SLE4442LIB_API long _stdcall Disconnect();

/// Reads from the main memory at the specified buffer
SLE4442LIB_API long _stdcall ReadMainMemory(BYTE* buffer, int offset, int* pnLen);

/// Writes in the main memory at the specified buffer
SLE4442LIB_API long _stdcall UpdateMainMemory(BYTE* buffer, int offset, int nLen);

/// Verify the PIN
SLE4442LIB_API long _stdcall VerifyPIN(BYTE* pin, int nLen);

/// Changes the PIN
SLE4442LIB_API long _stdcall ChangePIN(BYTE* oldpin, int oldLen, BYTE* newpin, int newLen);

/// Waits for a smart card inserted
SLE4442LIB_API long _stdcall WaitForSmartCardInserted(char* szReader, int timeout);

/// Waits for a smart card removed
SLE4442LIB_API long _stdcall WaitForSmartCardRemoved(char* szReader, int timeout);

/// Cancels waiting
SLE4442LIB_API long _stdcall CancelWaiting();

/// Sets the card handle
SLE4442LIB_API long _stdcall SetCardHandle(SCARDHANDLE hCard, char* szReader);

/// Check if the smart card is inserted
SLE4442LIB_API bool _stdcall IsSmartCardPresent();

/// Writes the protection memory bits
SLE4442LIB_API long _stdcall WriteProtectionMemoryBits(BYTE* buffer, int offset, int nLen);