Note per l'installazione
----------------------------------

Le dll NSCAPI.dll e NCSNAPI.dll devono essere registrate con il seguente comando regasm:

regasm /tlb /codebase <pathtonscapi>/NSCAPI.dll

regasm /tlb /codebase <pathtoncnsapi>/NSLE4442API.dll

