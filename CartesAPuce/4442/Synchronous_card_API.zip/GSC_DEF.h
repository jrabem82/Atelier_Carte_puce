/*
*********************************************************************
*
*  Copyright : Gemplus (c) 1991-2004, All rights reserved.
*
*
*********************************************************************
* Version History:
*
* V 0.04 7/29/2004  : Add ifdef __cplusplus
* V 0.03 5/21/2003  : Add fonction define
* V 0.02 5/19/2003  : Add new define
* V 0.01 5/16/2003  : First Revision
*
*********************************************************************
*/

#ifndef _GSC_DEF_H
#define _GSC_DEF_H

#include "WinScard.h"

// *********************************************************************
// Parameters value section
// *********************************************************************
// the value 0x00 is RFU in this section

// For bCardType
#define  ICC_2_WIRE								0x01
#define  ICC_3_WIRE								0x02
#define  ICC_SDA								0x03
#define  ICC_4402								0x04
#define  ICC_4403								0x05
#define  ICC_4433								0x06
#define  ICC_4404								0x07
#define  ICC_896								0x08

// For bSubCardType
#define ADDR_1_BYTE								0x01
#define ADDR_2_BYTES							0x02
#define ADDR_3_BYTES							0x03
#define PAGE_8_BYTES							0x04
#define PAGE_16_BYTES							0x05
#define PAGE_32_BYTES							0x06
#define PAGE_64_BYTES							0x07
#define PAGE_128_BYTES							0x08
#define NO_SUB_CARD_TYPE						0x09

// *********************************************************************
//// Error code section
// *********************************************************************

#define  GEM_SUCCESS                            0x00000000

#define  GEM_E_INVALID_HANDLE					0x00000001
#define  GEM_E_NO_SERVICE						0x00000002
#define  GEM_E_INVALID_PARAMETERS				0x00000003

#define  GEM_E_NO_READERS_AVAILABLE				0x00000004
#define  GEM_E_NO_SMARTCARD						0x00000005
#define  GEM_E_CARD_UNSUPPORTED					0x00000006

#define  GEM_E_UNKNOWN_CARD						0x00000007


#define  GEM_E_INSUFFICIENT_BUFFER				0x00000008
#define  GEM_E_PROTOCOL_NOT_SUPPORTED			0x00000009
#define  GEM_E_WRITE_ERROR						0x0000000A
#define  GEM_E_INVALID_ADDRESS					0x0000000B
#define  GEM_E_INVALID_LENGTH					0x0000000C


#define  GEM_E_NO_ACCESS						0x0000000D
#define  GEM_E_WRONG_PWD						0x0000000E

#define  GEM_E_UNKNOWN_ERROR					0x0000000F
#define  GEM_E_INVALID_FIRMWARE_ANSWER			0x00000010
#define  GEM_E_EARLY_END_OF_FILE				0x00000011


// *********************************************************************
//// DLL Header section
// *********************************************************************


#ifdef __cplusplus
extern "C" {
#endif

long GCSInit(IN SCARDHANDLE hCard);

long GCSClose(IN SCARDHANDLE hCard);

long GSCPowerUp (	IN SCARDHANDLE hCard,
					IN OUT LPBYTE pbRecvBuffer,
					IN OUT LPDWORD pcbRecvLength);

long GSCPowerDown(IN SCARDHANDLE hCard);

long  GSCWrite (	IN SCARDHANDLE hCard,
					IN BYTE bCardType,
					IN BYTE bSubCardType,
					IN DWORD dwAddressToWrite,
					IN LPBYTE pbByteToWrite,
					IN DWORD dwLengthToWrite);

long GSCWriteProtectionBits (	IN SCARDHANDLE hCard,
								IN BYTE bCardType,
								IN BYTE bSubCardType,
								IN DWORD dwAddressToWrite,
								IN LPBYTE pbByteToWrite,
								IN DWORD dwLengthToWrite);

long  GSCWriteSecurityMemory (	IN SCARDHANDLE hCard,
							   	IN BYTE bCardType,
							   	IN BYTE bSubCardType,
							   	IN DWORD dwAddressToWrite,
							   	IN LPBYTE pbByteToWrite,
							   	IN DWORD dwLengthToWrite);

long GSCRead (	IN SCARDHANDLE hCard,
				IN BYTE bCardType,
				IN BYTE bSubCardType,
				IN DWORD dwAddressToRead,
				IN DWORD dwLengthToRead,
				OUT LPBYTE pbRecvBuffer,
				IN OUT LPDWORD pdRecvBufferLength);

long GSCReadProtectionBits (	IN SCARDHANDLE hCard,
							 	IN BYTE bCardType,
							 	IN BYTE bSubCardType,
							 	IN DWORD dwAddressToRead,
							 	IN DWORD dwLengthToRead,
							 	OUT LPBYTE pbRecvBuffer,
							 	IN OUT LPDWORD pdRecvBufferLength);

long GSCReadSecurityMemory (	IN SCARDHANDLE hCard,
							 	IN BYTE bCardType,
							 	IN BYTE bSubCardType,
							 	IN DWORD dwAddressToRead,
							 	IN DWORD dwLengthToRead,
							 	OUT LPBYTE pbRecvBuffer,
							 	IN OUT LPDWORD pdRecvBufferLength);

long GSCVerify ( 	IN SCARDHANDLE hCard,
					IN BYTE bCardType,
					IN DWORD dwCodeLength,
					IN LPBYTE pbCodeToVerify);

long GSCErase (	IN SCARDHANDLE hCard,
				IN BYTE bCardType,
				IN BYTE bSubCardType,
				IN DWORD dwAddressToErase,
				IN DWORD dwLengthToErase);


long GSCRestore (IN SCARDHANDLE hCard,
				 IN BYTE bCardType,
				 IN BYTE bSubCardType);

#ifdef __cplusplus
}
#endif


#endif //_GSC_DEF_H
// END OF FILE.
